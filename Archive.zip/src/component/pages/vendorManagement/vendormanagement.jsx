import React from 'react'

const vendormanagement = () => {
  return (
    <div>
      This is Vendor Management page
    </div>
  )
}

export default vendormanagement
