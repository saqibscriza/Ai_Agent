import React from 'react'

const callMonitoring = () => {
  return (
    <div>
      This is Call Monitoring page
    </div>
  )
}

export default callMonitoring
