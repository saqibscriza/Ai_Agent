import React from 'react'

const setting = () => {
  return (
    <div>
      This is Setting page
    </div>
  )
}

export default setting
