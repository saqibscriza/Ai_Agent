import React from 'react'

const widget = () => {
  return (
    <div>
      <h3>widget page</h3>
    </div>
  )
}

export default widget
