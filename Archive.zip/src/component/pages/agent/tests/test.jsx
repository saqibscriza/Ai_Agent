import React from 'react'

const test = () => {
  return (
    <div>
      <h3>test page</h3>
    </div>
  )
}

export default test
