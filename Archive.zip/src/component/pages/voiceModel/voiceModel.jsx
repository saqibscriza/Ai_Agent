import React from 'react'

const voiceModel = () => {
  return (
    <div>
      This is Voice Model page
    </div>
  )
}

export default voiceModel
