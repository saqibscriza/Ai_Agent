import React from 'react'

const dashboard = () => {
  return (
    <div className='' style={{color:'red'}}>
      Depend On Backend Response...
    </div>
  )
}

export default dashboard
