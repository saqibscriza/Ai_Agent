import React from 'react'

const billingSubscription = () => {
  return (
    <div>
      This is Billing & Subscription page
    </div>
  )
}

export default billingSubscription
